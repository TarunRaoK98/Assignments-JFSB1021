package com.banking;

public class AccountHolder {
	
	private final int accountNumber;
	private double accountBalance;
	private String name;
	
	public static int count;
	
	static {
		count = 10000;
	}
	
	public AccountHolder(String name, double accountBalance) {
		super();
		this.accountNumber = getNumber();
		this.accountBalance = accountBalance;
		this.name = name;
	}
	
	public static int getNumber() {
		
		return count++;
	}
	
	

	@Override
	public String toString() {
		return "AccountHolder [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", name=" + name
				+ "]";
	}
	
	public double deposit (double amount) {
		
		accountBalance += amount;
		return accountBalance;
	}
	
	public double withdraw(double amount) {
		
		if(accountBalance >= amount)
			accountBalance -= amount;
		
		return accountBalance;
	}

	public static void main(String[] args) {
		
		AccountHolder one = new AccountHolder("Sunil", 10000);
		System.out.println(one);
		one.deposit(1500);
		one.withdraw(125);
		//one = new AccountHolder("Sunil", 10000);
		System.out.println(one);
	}

}
