package com.newBaby;

public class Baby {
	
	private double weight;
	private double height;
	private double BMI;
	
	public Baby(double weight, double height) {
		super();
		this.weight = weight;
		this.height = height;
	}

	public double calcBMI() {
		
		BMI = weight / height / height;
		return BMI;
	}
	
	public int checkHealth() {
		
		double bmi = calcBMI();
		if(bmi < 18.5)
			return -1;
		else if (bmi == 18.5)
			return 0;
		else
			return 1;
	}

	public static void main(String[] args) {
		
		Baby one = new Baby(80, 1.7);
		int one_health = one.checkHealth();
		if(one_health<0)
			System.out.println("Undernourished");
		else if (one_health == 0)
			System.out.println("Healthy");
		else
			System.out.println("OverNourished");

	}

}
