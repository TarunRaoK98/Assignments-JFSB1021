SELECT * FROM book_store;
SELECT * FROM book_store where (book_store.price>150);
SELECT * FROM book_store GROUP BY publisher;
SELECT * FROM book_store ORDER BY price;
SELECT Name FROM book_store WHERE Name LIKE 'm%' OR Name LIKE 'p%';