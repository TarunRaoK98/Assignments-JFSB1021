package com.day1;

public class A3 {
	
	public static void main(String[] args) {
		
		float f=(1/4) *10;
		int i = Math.round(f);
		System.out.println(i);
		// 0
		
		int i1 = 0XCAFE;
		//boolean b = 0;	//invalid
		char c = 'A';
		//byte b1 = 128;	//invalid
		//char c = ""A"";"	//invalid
		
		int x= 2;
		 int y= 1;
		 for (int z = 0; z < 5; z++){
		  if (( ++x > 2 ) || (++y > 2)){
		   x++;
		 }}
		 System.out.println(x + " " + y);
		 //0
		 //12 1
	}

}
