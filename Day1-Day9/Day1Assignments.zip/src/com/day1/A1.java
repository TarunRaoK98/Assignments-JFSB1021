package com.day1;

import java.util.*;

public class A1 {

	public static void main(String[] args) {
		
		A1 a1 = new A1();
		//a1.isPrime(5);
		//a1.isArmstrong(139);
		//a1.palindrome();
		int temp[] = {1,2,2,3,4,5,6,6};		
		a1.removeDuplicates(temp);
	}
	
	boolean isPrime(int n) {
		boolean flag = false;
		int count = 0;
		
		for(int i = 1; i <=n; i++) {
			if(n%i == 0)
				count++;
		}
		
		if (count == 2)
			flag = true;
		
		return flag;
	}
	
	boolean isArmstrong(int number) {
		
		int length = 0;
		int sum = 0;
		int temp = number;
		
		while(temp > 0) {
			length++;
			temp /= 10;
		}
		
		temp = number;
		while(number > 0) {
			int digit = number % 10;
			number = number / 10;
			sum += Math.pow(digit, length);
		}
		
		return temp == sum;
	}
	
	void palindrome() {
		
		Scanner sc = new Scanner(System.in);
		
		while(sc.hasNext()) {
			String word = sc.next();
			
			if(isPalindrome(word))
				System.out.println(word);
		}
		
		sc.close();
	}
	
	boolean isPalindrome(String word) {
		String wordReverse = "";
		
		for(int i = word.length()-1; i>=0; i--) {
			wordReverse += word.charAt(i);
		}
		
		return word.equals(wordReverse);
	}
	
	int[] removeDuplicates(int[] arr) {
		
		Arrays.sort(arr);
		
		if(arr.length<=1)
			return arr;
		int[] arr2 = new int[arr.length];
		int j = 0;
		
		for(int i = 0; i < arr.length-1; i++)
			if(arr[i] != arr[i+1])
				arr2[j++] = arr[i];
		
		arr2[j++] = arr[arr.length-1];
		
		return arr2;
	}
}
