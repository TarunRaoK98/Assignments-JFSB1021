package pack1;

public interface Automobile {
	
	String start();
	int increaseSpeed(int n);
	String stop();

}
