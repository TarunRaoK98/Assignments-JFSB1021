package pack1;

public abstract class Vehicle implements Automobile {
	protected int regNo;
	protected String model;
	protected int currSpeed;
	
	public Vehicle(int regNo, String model, int currSpeed) {
		super();
		this.regNo = regNo;
		this.model = model;
		this.currSpeed = currSpeed;
	}

	@Override
	public String start() {
		
		return("Vehicle started");
	}

	@Override
	public int increaseSpeed(int n) {
		currSpeed += n;
		System.out.println("Speed increased to "+currSpeed);
		
		return currSpeed;
	}

	@Override
	public String stop() {
		return("Vehicle stopped");

		
	}
	
	
	
	
	
	

}
