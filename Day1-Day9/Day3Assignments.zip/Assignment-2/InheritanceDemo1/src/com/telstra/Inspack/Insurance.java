package com.telstra.Inspack;

import com.telstra.emppack.Employee;
import com.telstra.emppack.Manager;
import com.telstra.emppack.Programmer;

public class Insurance {


	public  double calcPremium(Employee emp)
	{
		 double premium=0.0;
		if (emp instanceof Manager)
		{
			Manager m=(Manager) emp;
			premium = 0.05*m.getbSal();
		}
		else if (emp instanceof Programmer)
		{
			Programmer p = (Programmer) emp;
			premium = 0.05*p.getbSal();
		}
		return premium;
	}
}
