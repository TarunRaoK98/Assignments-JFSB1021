package com.telstra.pack;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Main {

	public static void main(String[] args) {

		/*
		 * ArrayList a1 = new ArrayList(); // Default size = 10;
		 * 
		 * a1.add(10); a1.add(15.4545); a1.add('c'); a1.add("Java");
		 * 
		 * System.out.println(a1);
		 * 
		 * List<String> a2 = new ArrayList<String>();
		 * 
		 * a2.add("KT"); a2.add("Ananya"); a2.add("Shriya");
		 * 
		 * System.out.println(a2);
		 * 
		 * a2.add(1, "Meena"); a2.remove(2); System.out.println(a2);
		 * 
		 * ArrayList<String> subarr = new ArrayList<String>(); subarr.add("one");
		 * subarr.add("two"); a2.addAll(1, subarr); System.out.println(a2);
		 * System.out.println(a2.get(2));
		 * 
		 * for(String str: a2) { System.out.print(str+" "); }
		 * 
		 * Iterator<String> it = a2.iterator(); while(it.hasNext()) {
		 * System.out.println(it.next()); }
		 */
		
		List<Book> blist = new ArrayList<Book>();
		
		blist.add(new Book(1, "Java", 200));
		blist.add(new Book(2, "Jva", 500));
		blist.add(new Book(3, "Jaa", 700));
		blist.add(new Book(4, "Jav", 900));
		
		Iterator<Book> it1 = blist.iterator();
		
		while(it1.hasNext()) {
			System.out.print(it1.next()+" ");
		}
	}

}