package com.telstra.pack;

public class Book {
	
	private int bId;
	private String bName;
	private int bPrice;
	public Book(int bId, String bName, int bPrice) {
		super();
		this.bId = bId;
		this.bName = bName;
		this.bPrice = bPrice;
	}
	@Override
	public String toString() {
		return "Book [bId=" + bId + ", bName=" + bName + ", bPrice=" + bPrice + "]";
	}
	
	public static void main(String [] args) {
		
		
	}
}
